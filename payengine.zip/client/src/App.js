import './App.css';
import React, { useState, useEffect } from 'react';
import Onboarding from './components/onboarding';

const axios = require('axios');


const App = () => {

  // Declare a new state variable, which we'll call "count"
  const [merchandiseId, setMerchandiseId] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:3333/users/1', {}).then((response) => {
      console.log(response);
    });
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        {/* <>
          {merchandiseId && <Onboarding merchandiseId={merchandiseId} />}
        </> */}
      </header>
    </div >
  );
}

export default App;
