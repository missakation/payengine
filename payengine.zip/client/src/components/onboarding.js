import { loadPayengine } from "payengine";
import React, { useEffect } from 'react';

const Onboarding = (props) => {

    useEffect(() => {
        // Load Payengine on first render only
        loadPayengine({
            publicKey: "sk_test_AdBkVncvcz8La3Nr9w3GxBOb4Om2w8ULck0uQM6hxwXqUcyyOB7wkVbdcBUFGgj4h4VUxgoMPfHUTQ3nlHFd6I2WFX97XVOFNmkv",
        }).then((pe) => {
            console.log(pe)
        });
    }, []);


    return (
        <div className="App">
            <header className="App-header">
                <>
                    <pay-engine
                        type="boarding"
                        merchant-id={props.merchandiseId}>
                    </pay-engine>
                </>
            </header>
        </div>
    );
}

export default Onboarding;
